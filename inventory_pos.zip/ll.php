<center><body background="http://localhost/inventory_pos/logo.jpg" width ="500" height ="500">

<br><br><br><center><b>
<font name ="forte"  size="6" color="lightgreen">INVENTORY AND POINT OF SALE OF NSCA MULTI-PURPOSE COOPERATIVE</b><br><br></font></center>
<div align="right" class="style3">
  <table width="200" border="3">
    <tr>
      <td align="center" valign="middle"  bordercolor="#33FFFF" bgcolor="lightgreen" scope="col"><span class="style3"><a href="http://localhost/inventory_pos/adminlog.php">ADMIN </span></td>  
	  <tr>
      <td align="center" valign="middle" bordercolor="#33FFFF" bgcolor="lightgreen" scope="col"><span class="style3"><a href="http://localhost/inventory_pos/cashierlog.php">CASHIER </span></td>  
    </tr>
      </table>

<center>  
		   
 
</table>
		 
</form>
</html>