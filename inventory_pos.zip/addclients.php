<form action="saveclients.php" method="post">
Name:<br />
<input name="a" type="text" /><br />
Address:<br />
<input name="c" type="text" size="70" />
<br />
Birthday:<br />
<input name="d" type="text" /><br />
Contact Number:<br />
<input name="e" type="text" /><br />
<input name="submit" type="submit" value="save">
</form>