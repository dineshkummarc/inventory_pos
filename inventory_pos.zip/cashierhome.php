<?php
	require_once('auth.php');
?>
<br>
<font name= "century" size="6" color="yellowgreen"><b><center> INVENTORY AND POINT OF SALE OF NSCA MULTI-PURPOSE COOPERATIVE</center></b></font>
<br>
<link rel="stylesheet" href="./css/style.css" type="text/css" media="screen" charset="utf-8">
<link rel="stylesheet" type="text/css" href="pro_dropdown_2/pro_dropdown_2.css" />

<script src="pro_dropdown_2/stuHover.js" type="text/javascript"></script>
<style type="text/css">
<!--
.indexwraper{
width:70%;
height:500px;
border-style:solid;
border-width:thin;
margin:0 auto;
border-width: 3px;
}
-->
</style>
<link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css" />
  <script src="lib/jquery.js" type="text/javascript"></script>
  <script src="src/facebox.js" type="text/javascript"></script>
  <script type="text/javascript">
    jQuery(document).ready(function($) {
      $('a[rel*=facebox]').facebox({
        loadingImage : 'src/loading.gif',
        closeImage   : 'src/closelabel.png'
      })
    })
  </script>
</head>

<body>
<body background ="http://localhost/inventory_pos/logo.jpg">
<span class="preload1"></span>
<span class="preload2"></span>
</div><center><div style="width:24%; margin:0 auto; height:50px; border-style:solid; border-color:#FFFFFF;">
<ul id="nav">
	<li class="top"><a href="index.php" class="top_link"><span style="font-size:24px; font-weight:bold;">Logout</span></a></li>
	<li class="top"><a href="login-exec.php" id="products" class="top_link"><span class="down" style="font-size:24px; font-weight:bold;">Transaction</span></a>
						
	</li>
</ul><center>
</div>
</body>
</html>
