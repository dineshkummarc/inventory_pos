<?php
echo "Today is ".date("D"),"day";
echo "<br />";
echo date("M-d-Y");
echo "<br />";
echo time("h-m-s");
echo "<br />";

?>