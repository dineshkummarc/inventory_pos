<form action="addteam-exec.php" method="post">
<label>Customer Name
<input type="text" name="textfield">
</label>
</form>

