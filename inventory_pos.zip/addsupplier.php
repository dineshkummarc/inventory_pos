
<form action="savesupplier.php" method="post">
<font color ="blue">
code:<br />
<input name="a" type="text" /><br />
description:<br />
<input name="b" type="text" size="70" />
<br />
quantity:<br />
<input name="d" type="text" /><br />
price:<br />
<input name="e" type="text" /><br />
category:<br />
<input name="f" type="text" /><br />
supplier:<br />
<input name="g" type="text" /><br />
selling price:<br />
<input name="h" type="text" /><br />
<input name="submit" type="submit" value="save">
</font>
</form>
